import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt


#                             DATAREADER class Definition
class DataReader:
    """
       A class to read data from a CSV file.

       Attributes:
           file_path (str): Path to the CSV file.
       """
    def __init__(self, file_path):
        self.file_path = file_path
    #                         DataReader methods()= FillMissing data
    def read_csv(self):
        return pd.read_csv(self.file_path)


#                             PROCESSDATA class Definition
class ProcessData:
    """
        A class to preprocess workout data.

        Attributes:
            data (pd.DataFrame): The raw workout data.
    """
    #    ProcessData methods= preprocessdata()
    def __init__(self, data):
        self.data = data
    #    ProcessData methods= CheckMissingvalues()
    def preprocess(self):
        """
        Cleans and preprocesses the workout dataset by handling missing values.
        Ensures that essential columns exist, otherwise stops execution.
        """
        if 'BodyPart' not in self.data.columns or 'Level' not in self.data.columns:
            st.error("The required columns ('BodyPart', 'Level') are missing in the dataset.")
            st.stop()
        self.data['Equipment'] = self.data['Equipment'].fillna("Unknown")
        self.data['Desc'] = self.data['Desc'].fillna("No description available.")
        return self.data

#                             FilterUser selection class Definition
class FilterUserSelection:
    def __init__(self, data):
        self.data = data
    """
   Class to filter exercises based on user-selected criteria.
   """
    #    FilterUser methods= applyFilter()
    def applyFilter(self, user_level, body_part, num_exercises=5):
        """
       Filters exercises based on the user's fitness level and target body part.

       Args:
           user_level (str): The user's fitness level.
           body_part (str): The body part the user wants to train.
           num_exercises (int, optional): Number of exercises to return. Defaults to 5.

       Returns:
           pd.DataFrame: A filtered subset of exercises.
       """
        filtered_data = self.data[
            (self.data['Level'].str.lower() == user_level.lower()) &
            (self.data['BodyPart'].str.lower() == body_part.lower())
            ]
        #    FilterUser methods= getFilteredData()
        if filtered_data.empty:
            return pd.DataFrame()
        cluster = filtered_data['Cluster'].iloc[0]
        cluster_data = self.data[self.data['Cluster'] == cluster]
        return cluster_data.sample(n=num_exercises) if len(cluster_data) >= num_exercises else cluster_data

#                             GraphicalRepresentation class Definition
class GraphicalRepresentation:
    """
        Class that generates data visualizations.

        Attributes:
    """
    def __init__(self, data):
        self.data = data
        self.figure = None
        self.labels = []

    def generate_exercise_cluster_graph(self):
        """
        Generates a bar chart displaying the number of exercises per cluster.

        Returns:
            Generated matplotlib.figure.
        """
        cluster_counts = self.data['Cluster'].value_counts()
        self.figure, ax = plt.subplots(figsize=(8, 5))
        cluster_counts.plot(kind='bar', ax=ax)
        ax.set_title("Number of Exercises per Cluster")
        ax.set_xlabel("Cluster")
        ax.set_ylabel("Number of Exercises")
        ax.set_xticklabels(cluster_counts.index, rotation=0)
        return self.figure

    def generate_body_part_distribution_graph(self):
        """
       Generates a pie chart showing the distribution of exercises by body part.

       Returns:
           Generated matplotlib.figure.
       """
        body_part_counts = self.data['BodyPart'].value_counts()

        def autopct_format(pct):
            return f'{pct:.1f}%' if pct > 4 else ''

        self.figure, ax = plt.subplots(figsize=(8, 6))
        wedges, _, autotexts = ax.pie(
            body_part_counts,
            labels=None,
            autopct=autopct_format,
            startangle=90,
            textprops={'fontsize': 10}
        )
        ax.legend(
            wedges,
            body_part_counts.index,
            title="Body Parts",
            loc="center left",
            bbox_to_anchor=(1, 0, 0.5, 1)
        )
        ax.set_title("Distribution of Exercises by Body Part")
        return self.figure


#                     OutputDisplay class Definition
class OutputDisplay:
    def __init__(self):
        self.graph = None

    def generate_graph_output(self, graph):
        self.graph = graph

    def display(self):
        if self.graph is not None:
            st.pyplot(self.graph)
        else:
            st.text("No graph to display")


# APP CONTROLLER CLASS
class AppController:
    """
    The main controller class for managing data, user input, and UserInterface rendering.
    """
    def __init__(self, cleaned_data_path, preprocessed_data_path):
        self.cleaned_data_path = cleaned_data_path
        self.preprocessed_data_path = preprocessed_data_path
        self.cleaned_data = None
        self.preprocessed_data = None
        self.user_level = None
        self.body_part = None
        self.num_exercises = None
        self.recommendations = None
        self.graph_output = OutputDisplay()

    """Loads and preprocesses the dataset."""
    def load_data(self):
        self.cleaned_data = ProcessData(DataReader(self.cleaned_data_path).read_csv()).preprocess()
        self.preprocessed_data = DataReader(self.preprocessed_data_path).read_csv()

    """Retrieves user selections from the Streamlit UI."""
    def get_user_input(self):
        self.user_level = st.sidebar.selectbox("Select Your Fitness Level", self.cleaned_data['Level'].unique())
        self.body_part = st.sidebar.selectbox("Select Target Body Part", self.cleaned_data['BodyPart'].unique())
        self.num_exercises = st.sidebar.slider("Number of Exercises", min_value=1, max_value=10, value=5)

    """Filters exercise recommendations based on user input."""
    def process_recommendations(self):
        recommender = FilterUserSelection(self.preprocessed_data)
        self.recommendations = recommender.applyFilter(self.user_level, self.body_part, self.num_exercises)

    """Generates and displays data visualizations."""
    def visualize_data(self):
        graph_rep = GraphicalRepresentation(self.preprocessed_data)
        st.subheader("Data Visualizations")
        st.write("### Exercises per Cluster")
        st.pyplot(graph_rep.generate_exercise_cluster_graph())
        st.write("### Distribution of Exercises by Body Part")
        st.pyplot(graph_rep.generate_body_part_distribution_graph())

    """Displays recommended workouts."""
    def display_output(self):
        st.subheader("Recommended Workouts")
        if self.recommendations.empty:
            st.write("No recommendations available for the selected criteria.")
        else:
            st.write(self.recommendations[['Title', 'Desc', 'Type', 'Equipment']])

    """Runs the Streamlit application."""
    def run(self):
        st.title("Samantha Marckioni Health & Fitness App")
        st.sidebar.header("User Input")
        self.load_data()
        self.get_user_input()
        self.process_recommendations()
        self.display_output()
        self.visualize_data()

#INSTANTIATE AND RUN APP
app = AppController("C:/Users/luisn/Documents/Samantha_Personal_Health_App/data/cleaned_gym_data.csv",
                    "C:/Users/luisn/Documents/Samantha_Personal_Health_App/data/preprocessed_gym_data.csv")
app.run()


